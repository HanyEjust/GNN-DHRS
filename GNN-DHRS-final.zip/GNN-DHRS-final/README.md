# GNN-DHRS

Official reproducibility implementation for **“An Explainable Graph Attention Framework with Dual Hybrid Resampling for Imbalanced Brain Stroke Prediction.”**

GNN-DHRS combines leakage-safe preprocessing, ordered Borderline-SMOTE → SMOTEENN refinement, a directed positive-cosine patient graph, a two-layer similarity-aware multi-head GAT, weighted BCE, nested cross-validation, strictly inductive test-time inference, calibration, selective prediction, controlled baselines, ablations, and explainability utilities. The code is designed to calculate results from the datasets; it does **not** hard-code manuscript tables.

## Data

The manuscript evaluates three public benchmark files with 10 modeling predictors and target `stroke`:

- **DF-1:** 43,400 rows; 783 stroke / 42,617 non-stroke. Place as `data/raw/DF-1.csv`.
- **DF-2:** 4,981 rows; 248 stroke / 4,733 non-stroke. Public full-filled brain-stroke dataset: https://www.kaggle.com/datasets/zzettrkalpakbal/full-filled-brain-stroke-dataset . Place as `data/raw/DF-2.csv`.
- **DF-3:** 5,110 rows; 249 stroke / 4,861 non-stroke. https://www.kaggle.com/datasets/fedesoriano/stroke-prediction-dataset . Place as `data/raw/DF-3.csv`.

Dataset files are intentionally not redistributed. Verify DF-1 against the exact repository citation used in the manuscript before a final archival release.

## Reproducibility protocol

- 10 outer stratified folds and 5 inner stratified folds.
- Seeds: `11, 22, 33, 44, 55`; outer partitions are fixed by seed 11 for controlled stochastic repetitions.
- Numeric missing values: training-fold mean; categorical missing values: `Unknown`.
- One-hot encoding with unseen-category handling; numeric standardization using training statistics only.
- Pearson correlation filter `|r| > 0.90`; ANOVA F ranking; candidate retained counts 5, 10, 15, all.
- DHRS is training-only: Borderline-SMOTE followed by SMOTEENN; synthetic one-hot blocks are projected to valid one-hot states.
- Directed top-k cosine graph, `k=10`, positive similarities only, no forced symmetrization; self-loops are introduced inside GAT attention with weight 1.
- GAT: 2 layers, hidden dimension 128, 8 heads, dropout 0.30, LeakyReLU slope 0.20, GAT → BatchNorm → ReLU → Dropout.
- Similarity-aware attention implements `alpha_ij ∝ A_ij exp(u_ij)` directly.
- AdamW: lr `1e-3`, weight decay `5e-4`, betas `(0.9,0.999)`, epsilon `1e-8`; max 200 epochs.
- ReduceLROnPlateau: factor 0.5, patience 10, minimum lr `1e-6`; early stopping patience 20 on inner-validation F1.
- Threshold candidates: 0.10–0.90 by 0.10, selected using pooled inner-validation F1 only.
- Test inference is patient-by-patient and uses only original outer-training patients as reference nodes; there are no test-test edges.

## Installation

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

For CUDA, install the PyTorch/PyG wheels appropriate for the local CUDA runtime if the pinned generic wheels are not suitable.

## Run

```bash
python scripts/run_dataset_audit.py
python scripts/run_nested_cv.py
python scripts/run_baselines.py
python scripts/run_ft_transformer.py
python scripts/run_cross_dataset.py
python scripts/run_resampling_ablation.py
python scripts/run_selective_prediction.py
python scripts/run_statistical_validation.py
python scripts/make_outputs.py
```

Or run the core sequence:

```bash
python scripts/run_all.py
```

The one-factor-at-a-time sensitivity study is intentionally separate because it is computationally expensive:

```bash
python scripts/run_sensitivity.py
```

## Outputs

Results are written under `outputs/`:

- `tables/`: fold metrics, baselines, transfer, ablations, statistics and sensitivity.
- `predictions/`: untouched outer-test probabilities.
- `figures/`: class distribution, pooled ROC/PR and calibration figures.
- `checkpoints/`: reserved for frozen fold models used by explanation/robustness workflows.

## Explainability

`src/gnn_dhrs/explain.py` implements Kernel-SHAP helpers and fidelity/stability functions. The manuscript protocol uses 100 original outer-training background patients per fold (50/50 by class), 20 untouched outer-test explanations per fold (10/10 by class), five-edge relation explanations, ten perturbations for stability, and ten random-edge ablation repetitions. Explanations must be produced from the exact frozen outer-fold model; never retrain a different model solely for explanation.

## Important scientific note

This repository is a manuscript-derived reference implementation. Where the manuscript does not uniquely define a software-level choice, the repository fixes an explicit value in `docs/ASSUMPTIONS.md`. Those choices are not manuscript observations and should not be used to retroactively justify already reported numerical results. A reproducibility run should be compared with the manuscript and discrepancies should be reported rather than hidden.

## Repository structure

```text
configs/paper.yaml             experiment configuration
data/raw/                      user-supplied public datasets
src/gnn_dhrs/                 preprocessing, DHRS, graph, model, training, metrics, analyses
scripts/                       executable experiment entry points
outputs/                       generated tables, predictions, figures, checkpoints
docs/ASSUMPTIONS.md            explicit low-level implementation decisions
docs/manuscript_source.tex     manuscript snapshot used to derive this implementation
tests/                         unit tests
```

## License

Code is released under the MIT License. Dataset licenses remain with their original providers.
